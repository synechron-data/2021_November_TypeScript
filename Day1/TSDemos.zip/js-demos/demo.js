'use strict'
a = 10;
console.log(a);
console.log(typeof a);