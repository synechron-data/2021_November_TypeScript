// Variables created are optionally typesafe
// Untyped Variable - Not TypeSafe, Not get Intellisence (any)
// var data;
// data = 10;
// data = "ABC";

// Implicitly Typed - Type Inference
// var data = 10;
// data = "abc";           // Compile Time Error: Type 'string' is not assignable to type 'number'.

// var ename = "Manish";
// ename = 10;             // Compile Time Error: Type 'number' is not assignable to type 'string'

// Explicitly Typed
// var age: number;
// age = 10;
// age = "abc";           // Compile Time Error: Type 'string' is not assignable to type 'number'.

// var city: string;
// city = "Pune";

// Function to Add 2 Numbers
// function add(x, y) {
//     return x + y;
// }

// function add(x: any, y: any) {
//     return x + y;
// }

// function add(x: number, y: number) {
//     return x + y;
// }

// console.log(add(2, 3));
// console.log(add(2, "ABC"));
// console.log(add("ABC", "XYZ"));
// console.log(add("ABC", true));

// number / string / boolean / undefined / array / object / Date / RegExp / function / void
// All the new Types which are supported by JavaScript
// Lefthand Side of assignment Operator, all JS Types (Declaration)

// Typescript Types
// any / never / unknown / class / interface / enums / tuple / typeguards

var a: Array<number>;
var s: symbol;
var p: Promise<void>;
var data: never;

// Righthand Side of assignment Operator, API's will come
// If you want to use any API, You can only use them with proper configuration
// Based on target in tsconfig.json
// And lib section configured in your tsconfig.json

a = new Array<number>();
s = Symbol("Hello");
p = new Promise((resolve, reject) => { });

// Browser API (lib -> DOM) - All HTML 5 API's
// console
// document
// navigator
// screen

