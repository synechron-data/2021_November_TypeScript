// function hi() {
//     console.log("Hi World!");
// }

// // Error: Duplicate function implementation.
// function hi(name: string) {
//     console.log(`Hi, ${name}`);
// }

// hi();
// hi("Synechron");

// ------------------------------------------------------
function hi(): void;
function hi(name: string): void;

function hi(...args: string[]) {
    if (args.length === 0)
        console.log("Hi World!");
    else if (args.length === 1)
        console.log(`Hi ${args[0]}`);
    else
        throw new Error("Invalid Number of Arguments...");
}

hi();
hi("Synechron");
// hi("Synechron", "Pune");