function test1() {
    console.log(this);
}

// test1();

const test2 = function () {
    console.log(this);
}

// test2();

const test3 = () => {
    console.log(this);
}

// test3();

var p1 = { id: 1 };

test1.call(p1);
test2.call(p1);
test3.call(p1);