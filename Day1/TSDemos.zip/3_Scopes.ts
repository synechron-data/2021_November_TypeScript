// Global Scope
// Local Scope (Function Scope)
// Block Scope (Using let and const keyword)

// var i = 20;
// var i = 30;
// console.log(i);

// var j = 20;
// var j = "abc";          // Error: Subsequent variable declarations must have the same type.
// console.log(j);

// var i = 20;
// function test() {
//     var i = "Hello";
//     console.log("Inside Function: ", i);
// }

// test();
// console.log("Outside Function: ", i);  // Error: Cannot find name 'i'

// Using Var keyword, you will get, either Global or Function Scoping
// var does not support Block Scoping
// var i = 20;
// function test() {
//     if (true) {
//         var i = "Hello";
//         console.log("Inside, if block: ", i);
//     }
//     console.log("Inside, Function: ", i);
// }

// test();
// console.log("Outside Function: ", i);  // Error: Cannot find name 'i'

// Support Hoisting - Moving Declarations to the top
// a1 = "Hi";
// console.log(a1);
// var a1;

// Using Var keyword, you will get, either Global or Function Scoping
// var does not support Block Scoping

// var i = 100;
// console.log("Before, i is", i);

// // for (var i = 0; i < 5; i++) {
// //     console.log("Inside Loop, i is", i);
// // }

// for (var _i = 0; _i < 5; _i++) {
//     console.log("Inside Loop, _i is", _i);
// }

// console.log("After, i is", i);

// --------------------------------------------------------------------------------

// let i = 20;
// let i = 30;             // Compile Time Error: Cannot redeclare block-scoped variable 'i'
// console.log(i);

// Does not Support Hoisting
// a1 = "Hi";
// console.log(a1);
// let a1;

var i = 100;
console.log("Before, i is", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside Loop, i is", i);
}

console.log("After, i is", i);