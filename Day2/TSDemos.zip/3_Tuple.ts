// TypeGuard Array
var dataArr1: (number | string)[];
dataArr1 = [1, "Manish"];
dataArr1 = ["Manish", 1];
dataArr1 = ["Manish", "Pune"];
dataArr1 = [1, 2, 3, 4];
dataArr1 = [1, "Manish", 2, "Pune"];

// Tuple - Stores a fixed collection of values of same or varied types, maintaining the sequence
let dataRow: [number, string];
dataRow = [1, "Manish"];
// dataRow = ["Manish", 1];
// dataRow = ["Manish", "Pune"];
// dataRow = [1, 2, 3, 4];
// dataRow = [1, "Manish", 2, "Pune"];

function insert(data: [number, string]) {

}

insert([1, "Manish"]);