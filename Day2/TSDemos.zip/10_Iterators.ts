class Queue<T> implements IterableIterator<T> {
    private _data: T[] = [];
    private _i = 0;

    push(d: T) {
        this._data.push(d);
    }

    pop(): T | undefined {
        return this._data.shift();
    }

    public next(): IteratorResult<T> {
        if (this._i < this._data.length) {
            return {
                done: false,
                value: this._data[this._i++]
            }
        } else {
            return {
                done: true,
                value: undefined
            }
        }
    }

    [Symbol.iterator](): IterableIterator<T> {
        return this;
    }
}

var numbersQ = new Queue<number>();
numbersQ.push(10);
numbersQ.push(20);
numbersQ.push(30);

for (const item of numbersQ) {
    console.log(item);
}