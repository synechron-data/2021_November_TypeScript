module.exports = function (env) {
    var env_file = env.WEBPACK_SERVE ? 'dev' : 'prod';
    return require(`./config/webpack.${env_file}.js`)(env);
}

// const HtmlWebpackPlugin = require("html-webpack-plugin");

// module.exports = {
//     mode: 'development',

//     entry: {
//         app: './src/main.ts'
//     },

//     resolve: {
//         extensions: ['.ts', '.js']
//     },

//     module: {
//         rules: [
//             {
//                 test: /\.ts?$/,
//                 use: 'ts-loader',
//                 exclude: /node_modules/
//             }
//         ]
//     },

//     plugins: [
//         new HtmlWebpackPlugin({
//             template: './public/index.html',
//             filename: './index.html',
//             scriptLoading: 'blocking'
//         })
//     ],

//     output: {
//         publicPath: 'http://localhost:3000',
//         filename: '[name].js'
//     },

//     devServer: {
//         port: 3000,
//         historyApiFallback: true,
//         client: {
//             logging: "none"
//         },
//         devMiddleware: {
//             stats: 'minimal'
//         },
//         open: {
//             app: {
//                 name: 'Chrome'
//             }
//         },
//         hot: true
//     }
// };